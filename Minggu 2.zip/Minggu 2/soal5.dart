//while
void main() {
  var i = 1;
  var i2 = 20;
  var i3 = 16;
  print('LOOPING PERTAMA');
  while (i <= 20) {
    if (i % 2 == 0) {
      print('$i - I Love Coding');
    }
    i++;
  }
  print('LOOPING KEDUA');
  while (i2 > 16) {
    if (i2 % 2 == 0) {
      print('$i2 - I will become a mobile');
    }
    i2--;
  }
  print('DEVELOPER');
  while (i3 > 0) {
    if (i3 % 2 == 0) {
      print('$i3 - I will become a mobile developer');
    }
    i3--;
  }
}