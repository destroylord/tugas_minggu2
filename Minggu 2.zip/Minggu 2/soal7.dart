void main() {

  for (int i = 1; i <= 4; i++) {
    // for (int j = 1; j <= 8; j ++) {
       print("#" * 8);
    // }
  }

}