void main() {
  var i = 0;
  for (i; i <= 10; i++) {
    print("#" * i);
  }
}